/**
 * Author: Yi Guo
 * Andrew ID: yiguo
 * <p>
 * BookModel Class
 * Package: ds
 * <p>
 * Description:
 * This Java class is serves as a model in MVC. It provides methods to connect to the Open Library API and log search info to mongodb.
 * It encapsulates functionality related to searching for books, retrieving detailed book information,
 * logging search activities, and generating dashboard analyses based on search logs for dashboard display.
 * <p>
 * The class leverages the Google Gson library for JSON processing and the MongoDB Java Driver for
 * logging search activities to a MongoDB database.
 * <p>
 * Usage:
 * 1. Create an instance of BookModel using the default constructor.
 * 2. Call the searchBook method with the desired search tag, e.g., searchBook("Java Programming").
 * 3. Retrieve the search result or handle any errors accordingly.
 * - The search result is a JSON string containing detailed information about the book.
 * - In case of errors, the method returns an error message.
 * <p>
 * Error handling - This model handles:
 * 1. Third party API not available.
 * 2. Third party API invalid data.
 * 3. MongoDB connection errors.
 * <p>
 * Logging:
 * - Search activities are logged to a MongoDB database for analysis and monitoring.
 * - The logging method can be invoked using the logging() method, providing relevant information.
 * - search term, request device, request time, Api request site, search time, search result are logged.
 * <p>
 * Dashboard Analysis:
 * - The dashboardAnalysis() method analyzes search logs and provides insights such as the most
 * frequently used device, search term, and the most recent search time.
 */

package ds;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import com.mongodb.MongoException;
import com.mongodb.client.*;
import org.bson.Document;


public class BookModel {
    // store the selected book ID in the Open Library API
    String ID;

    /*
     * Searches for a book based on the provided search tag.
     * This method performs URL encoding on the search tag and then uses it to retrieve the Open Library ID.
     * If a valid ID is obtained, the method proceeds to fetch and return detailed information about the book.
     *
     * @param searchTag The search tag used to look for a book.
     * @return Detailed information about the book or an error message if the search is unsuccessful.
     */
    public String searchBook(String searchTag) {
        String searchResult;

        searchTag = URLEncoder.encode(searchTag, StandardCharsets.UTF_8);
        // Obtain the Open Library ID for the search term
        // the ID is the random selected edition from the first 100 editions in the top 1 search result
        ID = searchID(searchTag);

        // Check if a valid ID is obtained
        if ((!ID.equals("Third party API not available.")) && (!ID.equals("No result found."))) {
            // If valid, fetch detailed information about the book using the ID
            searchResult = searchDetails(ID);
            return searchResult;
        } else {
            // If no valid ID is obtained, return the error message
            return ID;
        }

    }

    /*
     * Searches for book IDs based on a provided search tag using the Open Library API.
     * The search tag is transformed to lowercase and joined with '+' to create a URL-friendly format.
     * The Open Library search API is queried. The method will return the top 1 result and
     * randomly select an edition to be returned among the top 100 editions.
     *
     * @param searchTag The search tag for finding books.
     * @return A book ID selected randomly from the search results or an appropriate error message.
     */
    private String searchID(String searchTag) {
        // Transform search tag to lowercase and join with '+'
        searchTag = String.join("+", searchTag.toLowerCase().split("\\s+"));
        // Construct the search URL
        String searchURL = "https://openlibrary.org/search.json?title=" + searchTag;
        // Fetch results from the Open Library API
        String results = fetch(searchURL);

        // Check if the API is unavailable
        if (results.isEmpty()) {
            return "Third party API not available.";
        }

        // Parse JSON response using Gson
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(results, JsonObject.class);

        // Get the array of book documents from the response
        JsonArray books = jsonObject.get("docs").getAsJsonArray();
        // Check if no results were found
        if (books.size() == 0) {
            return "No result found.";
        } else { // get the top result and randomly select and edition among the top 100 edition
            JsonArray primary = books.get(0).getAsJsonObject().get("edition_key").getAsJsonArray();
            int book = new Random().nextInt(Math.min(primary.size(), 100));
            // return the selected book ID in the Open Library for book details searching
            String selected = primary.get(book).getAsString();
            return selected;
        }
    }

    /*
     * Retrieves detailed information about a book based on its Open Library ID using the Open Library API.
     * The book details include title, authors, number of pages, ISBN-10, publishers, publish date,
     * cover picture URL, and description.
     *
     * @param ID The Open Library ID of the book.
     * @return A JSON-formatted string containing detailed information about the book or an appropriate error message.
     */
    private String searchDetails(String ID) {
        // Construct the search URL for book details
        String searchURL = "https://openlibrary.org/api/books?&bibkeys=OLID:" + ID + "&jscmd=data&format=json";
        // Initialize a JsonObject to store search results
        JsonObject searchResult = new JsonObject();
        // Fetch results from the Open Library API
        String results = fetch(searchURL);
        // Check if the API is unavailable
        if (results.isEmpty()) {
            return "Third party API not available.";
        }

        Gson gson = new Gson();

        try {
            // Use ID to extract relevant information
            JsonObject jsonObject = gson.fromJson(results, JsonObject.class).get("OLID:" + ID).getAsJsonObject();

            // get title
            searchResult.addProperty("title", jsonObject.get("title").getAsString());
            // get authors name
            searchResult.addProperty("authors", joinArray(jsonObject.get("authors").getAsJsonArray()));

            // below will check if the field is null, if no information, return an empty string
            // else return the info
            // get number of pages
            if (jsonObject.get("number_of_pages") != null) {
                searchResult.addProperty("numberOfPages", jsonObject.get("number_of_pages").getAsInt());
            } else {
                searchResult.addProperty("numberOfPages", "");
            }

            // get isbn10
            if (jsonObject.get("identifiers") == null || jsonObject.get("identifiers").getAsJsonObject().get("isbn_10") == null) {
                searchResult.addProperty("ISBN10", "");
            } else {
                JsonArray isbn = jsonObject.get("identifiers").getAsJsonObject().get("isbn_10").getAsJsonArray();
                ArrayList<String> names = new ArrayList<String>();
                for (JsonElement e : isbn) {
                    names.add(e.getAsString());
                }
                searchResult.addProperty("ISBN10", String.join(", ", names));
            }

            // get publishers
            if (jsonObject.get("publishers") != null) {
                searchResult.addProperty("publishers", joinArray(jsonObject.get("publishers").getAsJsonArray()));
            } else {
                searchResult.addProperty("publishers", "");
            }

            // get publish date
            if (jsonObject.get("publish_date") != null) {
                searchResult.addProperty("publishDate", jsonObject.get("publish_date").getAsString());
            } else {
                searchResult.addProperty("publishDate", "");
            }

            // get the picture for the cover
            String pictureURL = "";
            if (jsonObject.get("cover") != null) {
                // first consider choosing large pictures
                if (jsonObject.get("cover").getAsJsonObject().get("large") != null) {
                    pictureURL = jsonObject.get("cover").getAsJsonObject().get("large").getAsString();
                } else if (jsonObject.get("cover").getAsJsonObject().get("medium") != null) { // then medium
                    pictureURL = jsonObject.get("cover").getAsJsonObject().get("medium").getAsString();
                } else { // then small
                    pictureURL = jsonObject.get("cover").getAsJsonObject().get("small").getAsString();
                }
            }

            searchResult.addProperty("picture", pictureURL);

            // then search for the description of the book using another endpoint
            searchURL = "https://openlibrary.org/works/" + ID + ".json";
            // fetch result
            results = fetch(searchURL);
            // check if API is available
            if (results.isEmpty()) {
                return "Third party API not available.";
            }

            // add the description property to the JSON object
            jsonObject = gson.fromJson(results, JsonObject.class);
            // if no description, make the property empty
            // else, add description
            if (jsonObject.get("description") != null) {
                try {
                    searchResult.addProperty("description", jsonObject.get("description").getAsString());
                } catch (Exception e) {
                    try {
                        searchResult.addProperty("description", jsonObject.get("description").getAsJsonObject().get("value").getAsString());
                    } catch (Exception e1) {
                        searchResult.addProperty("description", "");
                    }
                }
            } else {
                searchResult.addProperty("description", "");
            }
        } catch (Exception e) { // catch the Third party API invalid data error and send error message
            return "Third party API invalid data.";
        }
        // return the JSON containing book details as a string
        return searchResult.toString();
    }

    /*
     * Joins the "name" property values of a JsonArray into a comma-separated string.
     * The number of authors, publishers may be more than one. Use this method to join
     * them together.
     *
     * @param a The JsonArray containing elements with a "name" property.
     * @return A comma-separated string of "name" property values or an empty string if the array is empty.
     */
    public String joinArray(JsonArray a) {
        ArrayList<String> names = new ArrayList<String>();
        // loop through the JsonArray and join the strings together using comma
        for (JsonElement e : a) {
            names.add(e.getAsJsonObject().get("name").getAsString());
        }
        return String.join(", ", names);
    }


    /**
     * Retrieves the Open Library API URL used for the book details request.
     * The URL is constructed based on the Open Library ID obtained from the latest API request.
     * If the ID indicates that the API is not available or no results were found, an empty string is returned.
     * This is used for logging purposes.
     *
     * @return The Open Library API URL for the book details request or an empty string if error.
     */
    public String getRequestSite() {
        // return empty string if error
        // else return the primary API site to query for the book information
        // this is latter logged in the database
        return ((ID.equals("Third party API not available.")) || (ID.equals("No result found."))) ? "" : "https://openlibrary.org/api/books?&bibkeys=OLID:" + ID + "&jscmd=data&format=json";
    }

    /*
     * Logs search-related information to a MongoDB database.
     * Information logged includes the search term, device, request time, API request site, search time,
     * and the result of the search.
     *
     * @param searchTerm    The search term used in the request.
     * @param device        The device from which the request was made.
     * @param requestTime   The timestamp when the request was made.
     * @param ApiRequestSite The Open Library API URL used for the request to search book details.
     * @param searchTime    The time taken for the search operation, in seconds.
     * @param searchResult  The result of the search operation sent back to the mobile app.
     */
    public void logging(String searchTerm, String device, String requestTime, String ApiRequestSite, long searchTime, String searchResult) {
        // MongoDB connection string
        String connectionString = "mongodb://yiguo:3e6aAWKpZlPlx1Nh@ac-g0ihedn-shard-00-02.b0ltwju.mongodb.net:27017,ac-g0ihedn-shard-00-01.b0ltwju.mongodb.net:27017,ac-g0ihedn-shard-00-00.b0ltwju.mongodb.net:27017/Cluster0?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
        try (MongoClient mongoClient = MongoClients.create(connectionString)) {
            try {
                // Access the "yiguoProject4" database
                MongoDatabase database = mongoClient.getDatabase("yiguoProject4");
                // Access the collection
                MongoCollection<Document> collection = database.getCollection("LogData");
                // Create a document with search-related information
                Document document = new Document().append("requestTime", requestTime)
                        .append("searchTerm", searchTerm)
                        .append("device", device)
                        .append("ApiRequestSite", ApiRequestSite)
                        .append("searchTime", searchTime)
                        .append("searchResult", searchResult);
                // Insert the document into the collection
                collection.insertOne(document);

            } catch (MongoException e) {
                e.printStackTrace();
            } finally {
                mongoClient.close();
            }
        } catch (MongoException e) {
            // Handle MongoDB connection error
            System.out.println("MongoDB Connection Error");
        }
    }

    /**
     * Adds or increments the count of a key in a HashMap.
     * It is used in the dashboardAnalysis function to add new collection information
     * to a hashMap.
     *
     * @param key The key to be added or incremented.
     * @param map The HashMap in which the key count is managed.
     */
    private void addToMap(String key, HashMap<String, Integer> map) {
        // Check if the key is already present in the map
        if (map.containsKey(key)) {
            map.put(key, map.get(key) + 1);
        } else {
            // If the key is not present, add it with a count of 1
            map.put(key, 1);
        }
    }

    /*
     * Performs analysis on search logs stored in MongoDB to generate dashboard results.
     * The analysis includes determining the most used device, the most popular search term,
     * the most recent search time, and creating a table of search logs.
     *
     * @return An ArrayList containing the most used device, the most popular search term,
     *         the most recent search time, and a table of search logs.
     */
    public ArrayList<String> dashboardAnalysis() {
        // Initialize variables and data structures
        ArrayList<String> dashboardResults = new ArrayList<String>();
        Gson gson = new Gson();
        // for storing count of different devices and search terms
        HashMap<String, Integer> deviceCount = new HashMap<String, Integer>();
        HashMap<String, Integer> SearchCount = new HashMap<String, Integer>();
        // store the most popular device and search term
        String maxDevice = "";
        String maxSearchTerm = "";
        // store the most recent search time
        String mostRecentSearchTime = "";

        String device;
        String searchTerm;

        // store the html string for building the log table
        StringBuilder tableLogs = new StringBuilder();

        // MongoDB connection string
        String connectionString = "mongodb://yiguo:3e6aAWKpZlPlx1Nh@ac-g0ihedn-shard-00-02.b0ltwju.mongodb.net:27017,ac-g0ihedn-shard-00-01.b0ltwju.mongodb.net:27017,ac-g0ihedn-shard-00-00.b0ltwju.mongodb.net:27017/Cluster0?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
        try (MongoClient mongoClient = MongoClients.create(connectionString)) {

            MongoDatabase database = mongoClient.getDatabase("yiguoProject4");
            MongoCollection<Document> collection = database.getCollection("LogData");
            MongoCursor<Document> cursor = collection.find().iterator();

            try {
                // Iterate over search logs in the collection
                while (cursor.hasNext()) {
                    Document document = cursor.next();
                    // parse information from JSON
                    String s = document.toJson();
                    JsonObject record = gson.fromJson(s, JsonObject.class);
                    device = record.get("device").getAsString();
                    searchTerm = record.get("searchTerm").getAsString().toLowerCase();
                    mostRecentSearchTime = String.valueOf(record.get("searchTime").getAsLong());

                    // Update counts for devices and search terms
                    addToMap(device, deviceCount);
                    addToMap(searchTerm, SearchCount);

                    // Determine the most used device
                    // If the current added device's count is larger than the max device recorded
                    // update the maxDevice
                    if (maxDevice.isEmpty() || deviceCount.get(device) >= deviceCount.get(maxDevice)) {
                        maxDevice = device;
                    }

                    // Determine the most search term
                    // If the current added search term's count is larger than the max search term recorded
                    // update the maxSearchTerm
                    if (maxSearchTerm.isEmpty() || SearchCount.get(searchTerm) >= SearchCount.get(maxSearchTerm)) {
                        maxSearchTerm = searchTerm;
                    }

                    // Build a row of the table of search logs
                    tableLogs.append("<tr><td>")
                            .append(record.get("requestTime").getAsString())
                            .append("</td><td>")
                            .append(searchTerm)
                            .append("</td><td>")
                            .append(device)
                            .append("</td><td>")
                            .append(record.get("ApiRequestSite").getAsString())
                            .append("</td><td>").append(mostRecentSearchTime)
                            .append("</td><td>").append(record.get("searchResult").getAsString().replace("{", "").replace("}", ""))
                            .append("</td></tr>");
                }
            } finally {
                cursor.close();
            }
        } catch (MongoException e) {
            // Handle MongoDB connection error
            System.out.println("MongoDB Connection Error");
        }

        // Populate the ArrayList with analysis results
        dashboardResults.add(maxDevice);
        dashboardResults.add(maxSearchTerm);
        dashboardResults.add(mostRecentSearchTime);
        dashboardResults.add(tableLogs.toString());

        return dashboardResults;
    }

    /*
     * Make an HTTP request to a given URL
     * Source: Lab2: Interesting Picture
     *
     * @param urlString The URL of the request
     * @return A string of the response from the HTTP GET.  This is identical
     * to what would be returned from using curl on the command line.
     */
    private String fetch(String urlString) {
        String response = "";
        try {
            URL url = new URL(urlString);
            // create an HTTP connection
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            // Read all the text returned by the server
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            String str;
            // Read each line of "in" until done, adding each to "response"
            while ((str = in.readLine()) != null) {
                // str is one line of text readLine() strips newline characters
                response += str;
            }
            in.close();
        } catch (IOException e) {
            // catch third party api not available error
            System.out.println("Third Party API unavailable.");
        }
        return response;
    }

}
