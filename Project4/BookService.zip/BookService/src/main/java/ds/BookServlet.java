/**
 * Author: Yi Guo
 * Andrew ID: yiguo
 * <p>
 * The BookServlet class is a HttpServlet that serves as the controller in the Model-View-Controller (MVC) architecture
 * for a web application focused on book searches and dashboard analysis.
 * <p>
 * Responsibilities:
 * - Handles incoming HTTP GET requests related to book searches and dashboard analysis.
 * - Interacts with the BookModel to perform business logic and retrieve data.
 * - Generates responses and communicates with the client.
 * <p>
 * URL Patterns:
 * - "/getBooks/*": Handles book search requests, logging relevant information.
 * - "/getDashboard": Performs dashboard analysis and forwards to the dashboard.jsp view.
 * <p>
 * Usage:
 * - Accessed through URLs corresponding to the defined patterns.
 * - The servlet is initiated by instantiating the BookModel during initialization.
 */

package ds;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "BookServlet",
        urlPatterns = {"/getBooks/*", "/getDashboard"})
public class BookServlet extends HttpServlet {

    // The "business model" for this app
    BookModel model = null;

    /**
     * Initializes the servlet by instantiating the BookModel.
     * This method is called when the servlet is first created.
     */
    @Override
    public void init() {
        model = new BookModel();
    }

    /**
     * Handles HTTP GET requests and generates responses based on the request path.
     *
     * @param request  The HttpServletRequest object representing the client's request.
     * @param response The HttpServletResponse object for sending responses to the client.
     * @throws ServletException If there is a servlet-related problem.
     * @throws IOException      If there is an I/O problem.
     */

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        // Check if the request path is "/getBooks"
        if (request.getServletPath().equals("/getBooks")) {
            PrintWriter out = response.getWriter();
            response.setCharacterEncoding("UTF-8");
            response.setContentType("text/html; charset=UTF-8");

            // Get the current date and time for logging
            Date currentDate = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String requestTime = dateFormat.format(currentDate);

            // Get the device and search parameters from the request
            String device = request.getParameter("device");
            String search = request.getParameter("searchTerm");

            // Check if the server-side input search parameter is valid
            if (search == null || search.trim().isEmpty()) {
                out.println("Invalid server-side input.");
            } else {
                // Perform book search and log the request
                // get the start time of search
                long start = System.currentTimeMillis();
                String information = model.searchBook(search);
                // get the end time of search
                long end = System.currentTimeMillis();
                // calculate the search time taken (in seconds)
                long searchTime = (end - start) / 1000;
                out.println(information);

                // log search term, device, request time, API request site, search time and reply sent to the mobile
                model.logging(search, device, requestTime, model.getRequestSite(), searchTime, information);
            }


        }

        // Check if the request path is "/getDashboard"
        if (request.getServletPath().equals("/getDashboard")) {
            ArrayList<String> DashboardAnalysis;
            // Perform dashboard analysis and forward to the dashboard.jsp view
            DashboardAnalysis = model.dashboardAnalysis();

            // set the most popular device, search term and most recent search time, table logs as attributes
            request.setAttribute("device", DashboardAnalysis.get(0));
            request.setAttribute("searchTerm", DashboardAnalysis.get(1));
            request.setAttribute("searchTime", DashboardAnalysis.get(2));
            request.setAttribute("log", DashboardAnalysis.get(3));

            // forward view to dashboard.jsp
            RequestDispatcher view = request.getRequestDispatcher("dashboard.jsp");
            view.forward(request, response);

        }

    }
}

