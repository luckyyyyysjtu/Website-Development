package ds.cmu.booksearch;

/**
 * Author: Yi Guo
 * Andrew ID: yiguo
 * <p>
 * This class represents a book and its associated information, including title, authors, number of pages,
 * ISBN-10, publishers, publish date, description, and a URL for the book cover picture.
 * <p>
 * Usage:
 * - Create an instance of the Book class to store information about a specific book.
 */
public class Book {
    String title; // book title
    String authors; // book authors
    String numberOfPages; // number of pages for the book
    String ISBN10; // ISBN10 number of the book
    String publishers; // book publishers
    String publishDate; // book publish date
    String description; // book description
    String picture; // cover picture
}
