/**
 * Author: Yi Guo
 * Andrew ID: yiguo
 * This class represents the main activity for the Book Search application. It allows users to search for books
 * by providing a search term. The search results include book details and cover images retrieved from a remote service.
 * The class implements callback methods to update the UI with the search results.
 * <p>
 * Usage:
 * - Create an instance of SearchBook in the main activity.
 * - Set the click listener for the submit button to initiate the book search.
 * - Implement the callback methods `pictureReady` and `textReady` to handle the search results.
 */
package ds.cmu.booksearch;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SearchBook extends AppCompatActivity {

    SearchBook me = this;

    /*
     * Called when the activity is first created. Initializes the UI components, sets the click listener for
     * the submit button to initiate the book search, and handles callback for updating the UI with search results.
     *
     * Usage:
     * - Create an instance of SearchBook in the main activity.
     * - Set the click listener for the submit button to initiate the book search.
     * - Implement the callback methods `pictureReady` and `textReady` to handle the search results.
     *
     * @param savedInstanceState A Bundle containing the saved state of the activity.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*
         * The click listener will need a reference to this object, so that upon successfully finding book information from the web service, it
         * can callback to this object with the picture Bitmap and text details.
         */
        final SearchBook ma = this;


        // Find the "submit" button, and add a listener to it
        Button submitButton = (Button) findViewById(R.id.submit);


        // Add a listener to the send button
        submitButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View viewParam) {
                // Initialize UI components
                ImageView pictureView = (ImageView) findViewById(R.id.bookPicture);
                TextView resultView = (TextView) findViewById(R.id.result);
                // clear the results from previous search
                pictureView.setVisibility(View.INVISIBLE);
                resultView.setText("");
                // Get the search term from the input field
                String searchTerm = ((EditText) findViewById(R.id.searchTerm)).getText().toString();
                System.out.println("searchTerm = " + searchTerm);
                // Initiate a book search asynchronously
                GetBook gp = new GetBook();
                gp.search(searchTerm, me, ma); // Done asynchronously in another thread.  It calls pictureReady() and textReady() in this thread when complete.
            }
        });
    }

    /*
     * Callback method called by the GetBook object when the book cover image is ready. Updates the
     * ImageView with the retrieved image or displays a placeholder image if no picture is available.
     * Clears the search term input field and makes the ImageView visible.
     *
     * @param picture A Bitmap representing the book cover image.
     */
    public void pictureReady(Bitmap picture) {
        // Find the ImageView and EditText by their respective IDs
        ImageView pictureView = (ImageView) findViewById(R.id.bookPicture);
        TextView searchView = (EditText) findViewById(R.id.searchTerm);

        // Check if a valid picture is available
        if (picture != null) {
            pictureView.setImageBitmap(picture);
            System.out.println("picture");
            pictureView.setVisibility(View.VISIBLE);
        } else {
            // Display a placeholder image if no picture is available
            pictureView.setImageResource(R.drawable.noimage);
            System.out.println("No picture");
            pictureView.setVisibility(View.VISIBLE);
        }
        // Clear the search term input field
        searchView.setText("");
        pictureView.invalidate();
    }

    /*
     * Callback method called by the GetBook object when the book details or an error message is ready.
     * Updates the TextView with the search results or error message and clears the search term input field.
     *
     * @param text A string representing the book details or an error message.
     */
    public void textReady(String text) {
        // Find the TextView and EditText by their respective IDs
        TextView searchView = (EditText) findViewById(R.id.searchTerm);
        TextView resultView = (TextView) findViewById(R.id.result);
        // Display the search results or error message
        resultView.setText(text);
        // Clear the search term input field
        searchView.setText("");

    }
}
