/**
 * Author: Yi Guo
 * Andrew ID: yiguo
 * The `GetBook` class is responsible for searching for books based on a given search term
 * and retrieving book details, including an image, by sending HTTP request with search term
 * to a web service.
 * <p>
 * It receives the JSON formatted response from the web service and parses it into the Book class
 * object. It fetches the book cover picture URL and get a bitmap representation.
 * <p>
 * Then in the onPostExecute method, the pictures and book text details will be displayed in the
 * front end.
 */

package ds.cmu.booksearch;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;

import androidx.annotation.RequiresApi;

import com.google.gson.Gson;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;


public class GetBook {
    SearchBook book = null;   // for callback
    String searchTerm = null; // for storing search term
    Book searchedBook = null; // for parsing JSON
    String response = null; // for storing received response
    Bitmap picture = null; // for storing Bitmap book cover
    String details = null; // for storing texts that should be displayed in the front end

    /*
     * Initiates a book search based on the provided search term. The search is performed asynchronously,
     * and the results, including the book cover image and details, are delivered through the provided
     * callback interface `SearchBook`.
     *
     * @param searchTerm The term to search for books.
     * @param activity   The UI thread activity.
     * @param book       The callback interface for receiving book information.
     */
    public void search(String searchTerm, Activity activity, SearchBook book) {
        this.book = book;
        this.searchTerm = searchTerm;
        // execute background task
        new BackgroundTask(activity).execute();
    }

    private class BackgroundTask {

        private Activity activity; // The UI thread

        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }

        /*
         * Initiates background processing using a new thread. This method is responsible for
         * executing the background tasks, such as book search and data processing. After the
         * background tasks are completed, the UI updates are performed using the UI thread
         * associated with the provided `Activity`. The UI updates include invoking the
         * `onPostExecute` method to handle the results.
         *
         * This method is intended to be called within the context of the `BackgroundTask` class.
         *
         */
        private void startBackground() {
            new Thread(new Runnable() {
                public void run() {
                    doInBackground();
                    // activity should be set to MainActivity.this
                    // then this method uses the UI thread
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            onPostExecute();
                        }
                    });
                }
            }).start();
        }

        private void execute() {
            startBackground();
        }

        /*
         * Performs background tasks, including initiating a book search, processing the search response,
         * and extracting book details. The method handles error conditions and ensures that valid results
         * are processed further. The book search response is checked for various error messages such as
         * invalid user input, third-party API issues, connection errors, or invalid server-side input.
         * If the response is successful and does not contain error messages, the JSON response is parsed,
         * and book details are extracted for format a string to be displayed.
         *
         */
        private void doInBackground() {
            // Initiate a book search and retrieve the response
            response = search(searchTerm);
            // Check for error conditions in the search response
            if ((!response.equals("No result found.")) && (!response.equals("Invalid user input. Try again."))
                    && (!response.equals("Third party API not available.")) && (!response.equals("Third party API invalid data."))
                    && (!response.equals("Connection error.")) && (!response.equals("Invalid server-side input."))) {
                // If the response is successful, parse JSON and extract book details to format a string to be displayed
                parseJSON(response);
                getBookDetails();
            }
        }

        /*
         * Handles the UI updates after the background tasks are completed. Checks the search response
         * for error messages and invokes the appropriate callbacks through the `SearchBook` interface.
         * If the search was successful and no error messages are present, it calls the `pictureReady`
         * and `textReady` methods of the `SearchBook` interface to provide the book cover image and
         * details, respectively. If errors or no results are encountered, it calls the `textReady` method
         * with the appropriate error message.
         */
        public void onPostExecute() {
            // Check the search response for errors
            if ((!response.equals("No result found.")) && (!response.equals("Invalid user input. Try again."))
                    && (!response.equals("Third party API not available.")) && (!response.equals("Third party API invalid data."))
                    && (!response.equals("Connection error.")) && (!response.equals("Invalid server-side input."))) {
                // If the search is successful, invoke callbacks with book information
                // Callback to display the pictures and text details
                book.pictureReady(picture);
                book.textReady(details);
            } else {
                // If errors or no results, invoke callback with the appropriate error message
                book.textReady(response);
            }
        }

        /*
         * Initiates a book search by sending a request to a remote service and retrieves the search response.
         * The search term is URL-encoded and appended to the service URL along with device information. The
         * method handles various error conditions, such as invalid user input, connection errors, or server-side
         * issues, and returns appropriate error messages. If the request is successful (HTTP status code 200),
         * it reads the response from the connection's input stream.
         *
         * @param searchTerm The term to search for in the book database.
         * @return A string representing the search response, which may include book information or error messages.
         */
        private String search(String searchTerm) {
            // Initialize the response variable
            String response = "";
            try {
                // Check if the user input is valid
                if (searchTerm == null || searchTerm.trim().isEmpty()) {
                    return "Invalid user input. Try again.";
                }

                searchTerm = URLEncoder.encode(searchTerm, "UTF-8");

                // the URL for the web service
                String serviceURL = "https://silver-winner-5gqp7gr4qjgp276g5-8080.app.github.dev/getBooks";

                // Construct the full URL with parameters
                String fullUrl = serviceURL + "?searchTerm=" + searchTerm + "&device=" + URLEncoder.encode(Build.MANUFACTURER + " " + Build.DEVICE, "UTF-8");

                // Create a URL object
                URL url = new URL(fullUrl);

                // Open a connection to the URL
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                // Set the request method (GET in this case)
                connection.setRequestMethod("GET");

                // Get the response code
                int responseCode = connection.getResponseCode();

                // Check the HTTP response code
                if (responseCode == 200) {
                    // Read the response from the connection's input stream
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response += line;
                    }

                } else {
                    // if not reading successfully, return connection error
                    response = "Connection error.";
                }

            } catch (IOException e) {
                e.printStackTrace();
                response = "Connection error.";
            }
            return response;
        }


        /*
         * Parses a JSON string representing book information and populates the corresponding fields in
         * the `searchedBook` object. The method uses the Gson library to deserialize the JSON string
         * into a `Book` object. If the parsed book has a valid picture URL, it retrieves the book cover
         * image using the `getRemoteImage` method.
         *
         * @param jsonString A JSON string representing book information.
         */
        private void parseJSON(String jsonString) {
            // Create a Gson instance for deserialization
            Gson gson = new Gson();
            // Deserialize the JSON string into a Book object
            searchedBook = gson.fromJson(jsonString, Book.class);

            if (searchedBook.picture.equals("")) {
                return; // No valid picture URL, exit parsing
            }
            try {
                // Retrieve the book cover image from the remote URL
                picture = getRemoteImage(new URL(searchedBook.picture));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        /*
         * Constructs a detailed string representation of book information based on the fields of the
         * `searchedBook` object. The method formats the book details, including the title, authors,
         * number of pages, ISBN-10, publishers, publish date, and description. It checks for empty or
         * invalid values in each field and constructs the details string accordingly. This text
         * string will be displayed to the user.
         */
        private void getBookDetails() {
            // Construct the details string based on the fields of the searchedBook object
            details = ((searchedBook.title.isEmpty() || searchedBook.title.contains("?") || searchedBook.title.contains("�")) ? "" : "Title: " + searchedBook.title + "\n") +
                    ((searchedBook.authors.isEmpty() || searchedBook.authors.contains("?") || searchedBook.authors.contains("�")) ? "" : "Authors: " + searchedBook.authors + "\n") +
                    ((searchedBook.numberOfPages.isEmpty() || searchedBook.numberOfPages.contains("?") || searchedBook.numberOfPages.contains("�")) ? "" : "Number of Pages: " + searchedBook.numberOfPages + "\n") +
                    ((searchedBook.ISBN10.isEmpty() || searchedBook.ISBN10.contains("?") || searchedBook.ISBN10.contains("�")) ? "" : "ISBN10: " + searchedBook.ISBN10 + "\n") +
                    ((searchedBook.publishers.isEmpty() || searchedBook.publishers.contains("?") || searchedBook.publishers.contains("�")) ? "" : "Publishers: " + searchedBook.publishers + "\n") +
                    ((searchedBook.publishDate.isEmpty() || searchedBook.publishDate.contains("?") || searchedBook.publishDate.contains("�")) ? "" : "Publish Date: " + searchedBook.publishDate + "\n") +
                    ((searchedBook.description.isEmpty() || searchedBook.description.contains("?") || searchedBook.description.contains("�")) ? "" : "Description: " + searchedBook.description + "\n");
        }

        /*
         * Retrieves a remote image from the provided URL and decodes it into a Bitmap. The method opens
         * a connection to the given URL, retrieves the input stream, and decodes it into a Bitmap using
         * the BitmapFactory. If successful, the decoded Bitmap is returned; otherwise, null is returned.
         *
         * @param url The URL of the remote image to retrieve.
         * @return A Bitmap representing the remote image or null if an error occurs.
         */
        @RequiresApi(api = Build.VERSION_CODES.P)
        private Bitmap getRemoteImage(final URL url) {
            try {
                // Open a connection to the provided URL
                final URLConnection conn = url.openConnection();
                conn.connect();
                // Retrieve the input stream from the connection
                BufferedInputStream bis = new BufferedInputStream(conn.getInputStream());
                // Decode the input stream into a Bitmap
                Bitmap bm = BitmapFactory.decodeStream(bis);
                // Return the decoded Bitmap
                return bm;
            } catch (IOException e) {
                e.printStackTrace();
                // Return null in case of an error
                return null;
            }
        }
    }
}

