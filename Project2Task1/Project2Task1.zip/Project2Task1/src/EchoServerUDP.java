import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Scanner;

public class EchoServerUDP {
    public static void main(String args[]){
        System.out.println("The UDP server is running.");

        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter the port number: ");
        int serverPort = Integer.parseInt(keyboard.nextLine());

        DatagramSocket aSocket = null;
        byte[] buffer = new byte[1000];
        try{
            aSocket = new DatagramSocket(serverPort);
            DatagramPacket request = new DatagramPacket(buffer, buffer.length);
            while(true){
                aSocket.receive(request);
                DatagramPacket reply = new DatagramPacket(request.getData(),
                        request.getLength(), request.getAddress(), request.getPort());

                byte[] byteArray = new byte[request.getLength()];
                System.arraycopy(request.getData(), 0, byteArray, 0, request.getLength());

                String requestString = new String(byteArray);
                if (requestString.equals("halt!")){
                    aSocket.send(reply);
                    aSocket.close();
                    aSocket = null;
                    System.out.println("UDP Server side quitting");
                    break;
                } else{
                    System.out.println("Echoing: "+requestString);
                    aSocket.send(reply);}
            }
        }catch (SocketException e){System.out.println("Socket: " + e.getMessage());
        }catch (IOException e) {System.out.println("IO: " + e.getMessage());
        }finally {if(aSocket != null) aSocket.close();}
    }
}
